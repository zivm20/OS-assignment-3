209904606




*NOTE*
    if the end time of the process is -1, it means that the checksum wasn't the same.

checksum algo
    https://stackoverflow.com/questions/21001659/crc32-algorithm-implementation-in-c-without-a-look-up-table-and-with-a-public-li

udp ipv6
    https://gist.github.com/inaz2/0e77c276a834ad8e3131

shared memory
    https://users.cs.cf.ac.uk/dave/C/node27.html